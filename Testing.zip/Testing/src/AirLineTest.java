import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AirLineTest {
	
	@Test
	public void VisibleTest() throws InterruptedException {
		LoginPage l = new LoginPage();
		assertEquals(true,l.isloginpage());
		boolean b = l.isVisible();
		assertEquals(true, b);
	}
	/*@Test
	public void LoginTest() throws InterruptedException {
		LoginPage l = new LoginPage();
		assertEquals(true,l.isloginpage());
	}*/
	
	@Test
	public void DomesticTest() throws InterruptedException {
		
		DomesticFlight d = new DomesticFlight(null);
		assertEquals(true, d.filenotempty());
	}
	
	@Test
	public void InternationaTest() throws InterruptedException {
		
		InternationalFlight d = new InternationalFlight(null);
		assertEquals(true, d.filenotempty());
	}
	
	
}
